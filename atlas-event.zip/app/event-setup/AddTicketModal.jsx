"use client";

import { useState } from "react";
import { IoClose } from "react-icons/io5";
import { IoLocationOutline } from "react-icons/io5";

export default function AddTicketsModal({ isOpen, onClose }) {
  const [selectedType, setSelectedType] = useState(null);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-3xl w-full max-w-[600px] p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <IoClose className="w-6 h-6 text-gray-600" />
          </button>
          <h2 className="text-2xl font-semibold text-center flex-1 mr-8">
            Add Tickets
          </h2>
        </div>

        {/* Ticket Type Selection */}
        <div className="mb-8">
          <p className="text-gray-600 text-lg mb-4 text-center">
            What type of ticket do you want to add?
          </p>
          <div className="grid grid-cols-3 gap-4">
            {["Free", "Paid", "Donation"].map((type) => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`py-3 px-4 rounded-xl border text-center transition-colors
                  ${
                    selectedType === type
                      ? "border-blue-500 bg-blue-50 text-blue-500"
                      : "border-gray-200 hover:bg-gray-50"
                  }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Form Fields */}
        <div className="space-y-4 mb-8">
          <div className="flex items-center gap-4 py-2 border-b">
            <IoLocationOutline className="w-6 h-6 text-[#4C7BF4]" />
            <input
              type="text"
              placeholder="Ticket Name"
              className="w-full bg-transparent outline-none text-gray-700 placeholder-gray-400"
            />
          </div>
          <div className="flex items-center gap-4 py-2 border-b">
            <IoLocationOutline className="w-6 h-6 text-[#4C7BF4]" />
            <input
              type="text"
              placeholder="Cost"
              className="w-full bg-transparent outline-none text-gray-700 placeholder-gray-400"
            />
          </div>
          <div className="flex items-center gap-4 py-2 border-b">
            <IoLocationOutline className="w-6 h-6 text-[#4C7BF4]" />
            <input
              type="text"
              placeholder="Quantity"
              className="w-full bg-transparent outline-none text-gray-700 placeholder-gray-400"
            />
          </div>
          <div className="flex items-center gap-4 py-2 border-b">
            <IoLocationOutline className="w-6 h-6 text-[#4C7BF4]" />
            <input
              type="text"
              placeholder="Cost"
              className="w-full bg-transparent outline-none text-gray-700 placeholder-gray-400"
            />
          </div>
        </div>

        {/* Additional Options */}
        <div className="flex gap-4 mb-8">
          <button className="flex-1 py-3 px-4 rounded-lg bg-gray-50 text-gray-600 hover:bg-gray-100 transition-colors">
            + Add Promo Code
          </button>
          <button className="flex-1 py-3 px-4 rounded-lg bg-gray-50 text-gray-600 hover:bg-gray-100 transition-colors">
            + Add Start/End Date
          </button>
        </div>

        {/* Save Button */}
        <button className="w-full py-4 bg-[#4C7BF4] text-white rounded-lg hover:bg-blue-500 transition-colors">
          Save
        </button>
      </div>
    </div>
  );
}
