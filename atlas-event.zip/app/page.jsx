import Home from "./home/page";


export default function HomePage() {
  return (
    <main>
      <Home />
    </main>
  );
}
